# Smile Calendar (Sanitized for GitHub)

このプロジェクトは GitHub 公開用に認証情報を削除したバージョンです。

## セットアップ手順

1. `npm install` を実行して依存関係をインストールしてください。
2. `src/firebase.js` を開き、`firebaseConfig` オブジェクト内の `YOUR_API_KEY` などのプレースホルダーを、実際の Firebase プロジェクトの設定値に置き換えてください。

```javascript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID",
};
```

3. `npm start` で開発サーバーを起動します。
