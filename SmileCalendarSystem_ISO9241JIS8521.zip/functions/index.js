const functions = require("firebase-functions/v2");
const { onRequest } = require("firebase-functions/v2/https");
const admin = require("firebase-admin");
const cors = require("cors")({ origin: true });

admin.initializeApp();
const db = admin.firestore();

// 予約登録
exports.createReservation = onRequest(async (req, res) => {
  cors(req, res, async () => {
    if (req.method !== "POST") {
      return res.status(405).json({ error: "Method not allowed" });
    }

    const data = req.body;

    try {
      await db.collection("reservations").add(data);
      res.status(200).json({ message: "Reservation created" });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
});

// 予約取得
exports.getReservations = onRequest(async (req, res) => {
  cors(req, res, async () => {
    if (req.method !== "GET") {
      return res.status(405).json({ error: "Method not allowed" });
    }

    try {
      const snap = await db.collection("reservations").get();
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      res.status(200).json(list);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
});

// ログイン（IDトークン検証）
exports.verifyToken = onRequest(async (req, res) => {
  cors(req, res, async () => {
    if (req.method !== "POST") {
      return res.status(405).json({ error: "Method not allowed" });
    }

    const { token } = req.body;

    try {
      const decoded = await admin.auth().verifyIdToken(token);
      res.status(200).json({ uid: decoded.uid });
    } catch (error) {
      res.status(401).json({ error: "Invalid token" });
    }
  });
});
