# スマイルカレンダー（改良版）

歯科衛生管理を支援するWebアプリケーション

![Version](https://img.shields.io/badge/version-2.0-blue)
![React](https://img.shields.io/badge/React-19.2.0-61DAFB?logo=react)
![Firebase](https://img.shields.io/badge/Firebase-Latest-FFCA28?logo=firebase)
![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-Latest-38B2AC?logo=tailwind-css)

## 概要

スマイルカレンダーは、日々の歯みがきやオーラルケアを記録し、歯科通院の予約を管理できるWebアプリケーションです。

### 主な機能

- 📅 **カレンダー表示**: 月次カレンダーで記録を一覧表示
- 🦷 **日々の記録**: 朝・昼・夜の歯みがき、マウスウォッシュ、フロスの記録
- 📝 **メモ機能**: 自由記述メモ、通院記録
- 🏥 **予約登録**: 通院予約の登録・管理
- 🔐 **ユーザー認証**: Firebase Authenticationによる安全なログイン

### 改良版の特徴

- ✨ **洗練されたUI**: Tailwind CSSによるモダンなデザイン
- 🎨 **グラデーション背景**: 青からインディゴへの美しいグラデーション
- 📱 **レスポンシブ対応**: モバイル・タブレット・デスクトップに対応
- 🔤 **UDフォント**: BIZ UDPゴシックで視認性向上
- 💬 **確認ダイアログ**: 保存・削除時の誤操作防止
- 🎯 **アイコン**: 各項目に分かりやすい絵文字アイコン

## 技術スタック

### フロントエンド
- **React** 19.2.0
- **React Router DOM** 7.9.6
- **Tailwind CSS**
- **react-calendar** 6.0.0

### バックエンド
- **Firebase Firestore**: データベース
- **Firebase Authentication**: 認証
- **Firebase Hosting**: ホスティング

### フォント
- **BIZ UDPゴシック** (Google Fonts)

## セットアップ

### 前提条件

- Node.js 18.x 以上
- npm または yarn
- Firebaseアカウント

### インストール手順

1. **リポジトリのクローン**
   ```bash
   git clone <repository-url>
   cd smile-calendar
   ```

2. **依存関係のインストール**
   ```bash
   npm install
   ```

3. **Firebase設定**
   
   `src/firebase.js` ファイルを作成し、Firebase設定を追加してください：
   
   ```javascript
   import { initializeApp } from "firebase/app";
   import { getFirestore } from "firebase/firestore";
   import { getAuth } from "firebase/auth";

   const firebaseConfig = {
     apiKey: "YOUR_API_KEY",
     authDomain: "YOUR_AUTH_DOMAIN",
     projectId: "YOUR_PROJECT_ID",
     storageBucket: "YOUR_STORAGE_BUCKET",
     messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
     appId: "YOUR_APP_ID"
   };

   const app = initializeApp(firebaseConfig);
   export const db = getFirestore(app);
   export const auth = getAuth(app);
   ```

4. **開発サーバーの起動**
   ```bash
   npm start
   ```

## ビルドとデプロイ

```bash
# ビルド
npm run build

# Firebase Hostingへのデプロイ
firebase deploy --only hosting
```

## プロジェクト構造

```
smile-calendar/
├── src/
│   ├── components/      # UIコンポーネント
│   ├── pages/           # ページコンポーネント
│   ├── context/         # Reactコンテキスト
│   ├── firebase/        # Firebase関連
│   ├── utils/           # ユーティリティ
│   └── firebase.js      # Firebase初期化（要作成）
├── package.json
└── README.md
```

## ライセンス

このプロジェクトは教育目的で作成されています。
