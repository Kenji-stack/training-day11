// src/components/DayRecord.jsx
import React, { useEffect, useState } from 'react'
import { doc, setDoc, deleteDoc } from "firebase/firestore"
import { db } from "../firebase"
import { useAuth } from "../context/AuthContext"

export default function DayRecord({ dateKey, record, onSave }) {
  const { currentUser } = useAuth()

  const [form, setForm] = useState({
    brushingMorning: false,
    brushingNoon: false,
    brushingNight: false,
    mouthwash: false,
    floss: false,
    memo: ''
  })
  const [loading, setLoading] = useState(false)
  const [feedback, setFeedback] = useState({ type: '', message: '' })

  // Firestore の record を UI に反映（初回マウント時のみ）
  useEffect(() => {
    if (record) {
      setForm({
        brushingMorning: !!record.brushingMorning,
        brushingNoon: !!record.brushingNoon,
        brushingNight: !!record.brushingNight,
        mouthwash: !!record.mouthwash,
        floss: !!record.floss,
        memo: record.memo || ''
      })
    } else {
      setForm({
        brushingMorning: false,
        brushingNoon: false,
        brushingNight: false,
        mouthwash: false,
        floss: false,
        memo: ''
      })
    }
    // フィードバックをクリア
    setFeedback({ type: '', message: '' })
  }, [dateKey, record]);

  // 🔥 安全策: データ更新を検知したら強制的にloadingを解除
  useEffect(() => {
    if (loading) {
      console.log("データ更新を検知: loadingを解除します")
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [record])

  // フィードバックメッセージを3秒後に自動的に消す
  useEffect(() => {
    if (feedback.message) {
      const timer = setTimeout(() => {
        setFeedback({ type: '', message: '' })
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [feedback])

  // ------------------------
  // 🔥 Firestore へ保存
  // ------------------------
  const save = async () => {
    if (!currentUser) {
      setFeedback({ type: 'error', message: 'ログインが必要です' })
      return
    }
    if (!window.confirm("この内容で保存しますか？")) return

    console.log("保存処理開始 - loading:", loading)
    setLoading(true)
    setFeedback({ type: '', message: '' })

    try {
      const ref = doc(db, "oralCareRecords", dateKey)

      console.log("保存開始:", { dateKey, uid: currentUser.uid, form })

      // 5秒のタイムアウトを設定
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error("保存がタイムアウトしました（5秒）。通信環境を確認してください。")), 5000)
      );

      await Promise.race([
        setDoc(ref, {
          ...form,
          uid: currentUser.uid,
          updatedAt: new Date()
        }),
        timeoutPromise
      ]);

      console.log("保存完了:", dateKey)
      setFeedback({ type: 'success', message: '保存しました' })

      // 親コンポーネントに通知
      if (onSave) {
        onSave();
      }
    } catch (err) {
      console.error("保存エラー:", err)
      setFeedback({ type: 'error', message: `保存失敗: ${err.message}` })
    } finally {
      setLoading(false)
      console.log("保存処理終了 - loading:", false)
    }
  }

  // ------------------------
  // 🔥 Firestore の削除
  // ------------------------
  const remove = async () => {
    if (!currentUser) {
      setFeedback({ type: 'error', message: 'ログインが必要です' })
      return
    }
    if (!window.confirm("本当に削除しますか？")) return

    setLoading(true)
    setFeedback({ type: '', message: '' })

    try {
      const ref = doc(db, "oralCareRecords", dateKey)

      console.log("削除開始:", dateKey)
      await deleteDoc(ref)
      console.log("削除完了:", dateKey)

      setFeedback({ type: 'success', message: '削除しました' })

      // 親コンポーネントに通知
      if (onSave) {
        onSave();
      }
    } catch (err) {
      console.error("削除エラー:", err)
      setFeedback({ type: 'error', message: '削除に失敗しました' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bg-white rounded-xl shadow-md p-2">
      <h2
        id="record-title"
        className="text-sm font-semibold text-gray-800 mb-1 flex items-center space-x-2"
      >
        <span aria-hidden="true">📝</span>
        <span>{dateKey}</span>
      </h2>

      {/* フィードバックメッセージ */}
      {feedback.message && (
        <div
          role="alert"
          aria-live="polite"
          aria-atomic="true"
          className={`mb-2 p-2 rounded-lg font-medium text-xs ${feedback.type === 'success'
            ? 'bg-green-50 text-green-800 border border-green-200'
            : 'bg-red-50 text-red-800 border border-red-200'
            }`}
        >
          {feedback.message}
        </div>
      )}

      <form aria-labelledby="record-title">
        {/* チェックボックス - 横並び */}
        <div className="flex flex-wrap gap-4 mb-3 items-center">
          {/* 朝 */}
          <label className="flex items-center cursor-pointer whitespace-nowrap flex-shrink-0 py-2.5 px-2 -mx-2">
            <input
              type="checkbox"
              className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500 focus:ring-2 flex-shrink-0"
              checked={form.brushingMorning}
              onChange={(e) =>
                setForm({ ...form, brushingMorning: e.target.checked })
              }
              aria-label="朝の歯みがき"
            />
            <span className="ml-2 text-gray-700 flex items-center space-x-1 text-base">
              <span aria-hidden="true">🌅</span>
              <span>朝の歯みがき</span>
            </span>
          </label>

          {/* 昼 */}
          <label className="flex items-center cursor-pointer whitespace-nowrap flex-shrink-0 py-2.5 px-2 -mx-2">
            <input
              type="checkbox"
              className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500 focus:ring-2 flex-shrink-0"
              checked={form.brushingNoon}
              onChange={(e) =>
                setForm({ ...form, brushingNoon: e.target.checked })
              }
              aria-label="昼の歯みがき"
            />
            <span className="ml-2 text-gray-700 flex items-center space-x-1 text-base">
              <span aria-hidden="true">☀️</span>
              <span>昼の歯みがき</span>
            </span>
          </label>

          {/* 夜 */}
          <label className="flex items-center cursor-pointer whitespace-nowrap flex-shrink-0 py-2.5 px-2 -mx-2">
            <input
              type="checkbox"
              className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500 focus:ring-2 flex-shrink-0"
              checked={form.brushingNight}
              onChange={(e) =>
                setForm({ ...form, brushingNight: e.target.checked })
              }
              aria-label="夜の歯みがき"
            />
            <span className="ml-2 text-gray-700 flex items-center space-x-1 text-base">
              <span aria-hidden="true">🌙</span>
              <span>夜の歯みがき</span>
            </span>
          </label>

          {/* マウスウォッシュ */}
          <label className="flex items-center cursor-pointer whitespace-nowrap flex-shrink-0 py-2.5 px-2 -mx-2">
            <input
              type="checkbox"
              className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500 focus:ring-2 flex-shrink-0"
              checked={form.mouthwash}
              onChange={(e) =>
                setForm({ ...form, mouthwash: e.target.checked })
              }
              aria-label="マウスウォッシュ"
            />
            <span className="ml-2 text-gray-700 flex items-center space-x-1 text-base">
              <span aria-hidden="true">💧</span>
              <span>マウスウォッシュ</span>
            </span>
          </label>

          {/* フロス */}
          <label className="flex items-center cursor-pointer whitespace-nowrap flex-shrink-0 py-2.5 px-2 -mx-2">
            <input
              type="checkbox"
              className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500 focus:ring-2 flex-shrink-0"
              checked={form.floss}
              onChange={(e) =>
                setForm({ ...form, floss: e.target.checked })
              }
              aria-label="フロス"
            />
            <span className="ml-2 text-gray-700 flex items-center space-x-1 text-base">
              <span aria-hidden="true">🦷</span>
              <span>フロス</span>
            </span>
          </label>
        </div>

        {/* メモ */}
        <div className="mb-1">
          <label htmlFor="memo-input" className="block text-xs font-medium text-gray-700 mb-1">
            メモ
          </label>
          <textarea
            id="memo-input"
            className="w-full border border-gray-300 rounded p-1 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-xs"
            rows={2}
            cols={50}
            value={form.memo}
            onChange={(e) =>
              setForm({ ...form, memo: e.target.value })
            }
            placeholder="通院予約・通院記録・メモ"
            aria-describedby="memo-description"
          />
          <span id="memo-description" className="sr-only">
            通院予約や通院記録などのメモを入力できます
          </span>
        </div>
      </form>

      <div className="flex gap-2">
        <button
          onClick={save}
          disabled={loading}
          className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-medium py-1.5 px-2 rounded disabled:opacity-50 disabled:cursor-not-allowed transition duration-200 min-h-[44px] text-xs"
          aria-label="記録を保存"
        >
          {loading ? "保存中..." : "保存"}
        </button>

        <button
          onClick={remove}
          disabled={loading}
          className="flex-1 bg-red-600 hover:bg-red-700 text-white font-medium py-1.5 px-2 rounded disabled:opacity-50 disabled:cursor-not-allowed transition duration-200 min-h-[44px] text-xs"
          aria-label="記録を削除"
        >
          削除
        </button>
      </div>
    </div>
  )
}
