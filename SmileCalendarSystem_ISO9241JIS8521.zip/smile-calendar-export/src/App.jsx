// src/App.jsx
import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";

import { AuthProvider, useAuth } from "./context/AuthContext";

// Pages / Components
import Login from "./components/Login";
import CalendarPage from "./pages/CalendarPage";
import ReservationFormPage from "./pages/ReservationFormPage";
import ReservationConfirmPage from "./pages/ReservationConfirmPage";
import ReservationCompletePage from "./pages/ReservationCompletePage";

const PrivateRoute = ({ children }) => {
  const { currentUser } = useAuth();
  if (!currentUser) return <Navigate to="/login" replace />;
  return children;
};

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />

          <Route
            path="/"
            element={
              <PrivateRoute>
                <CalendarPage />
              </PrivateRoute>
            }
          />
          <Route
            path="/calendar"
            element={
              <PrivateRoute>
                <CalendarPage />
              </PrivateRoute>
            }
          />

          <Route
            path="/reserve"
            element={
              <PrivateRoute>
                <ReservationFormPage />
              </PrivateRoute>
            }
          />
          <Route
            path="/reserve/confirm"
            element={
              <PrivateRoute>
                <ReservationConfirmPage />
              </PrivateRoute>
            }
          />
          <Route
            path="/reserve/complete"
            element={
              <PrivateRoute>
                <ReservationCompletePage />
              </PrivateRoute>
            }
          />


          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}
