// src/pages/CalendarPage.jsx
import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import DayRecord from "../components/DayRecord";
import CalendarUI from "../components/CalendarUI";
import { getRecord } from "../firebase/reservationApi"; // 個別取得用（既存）
import { getOralCareRecords } from "../firebase/oralCareApi"; // 全件取得用（新規）

export default function CalendarPage() {
  const navigate = useNavigate();
  const { currentUser } = useAuth();

  const [selectedDate, setSelectedDate] = useState(() => {
    const today = new Date();
    return today.toISOString().split("T")[0];
  });
  const [record, setRecord] = useState(null);
  const [recordsByDate, setRecordsByDate] = useState({}); // カレンダーアイコン用全データ

  // 全記録を取得してカレンダーアイコンを更新する関数
  const fetchAllRecords = useCallback(async () => {
    if (currentUser) {
      const allRecords = await getOralCareRecords();
      setRecordsByDate(allRecords);
    }
  }, [currentUser]);

  // 選択された日付の記録を取得する関数
  const fetchSelectedRecord = useCallback(async (date) => {
    if (currentUser && date) {
      // reservationApiのgetRecordは引数がdateのみだが、中身が間違っている可能性があるため
      // ここではoralCareApiを使いたいところだが、既存ロジックを壊さないよう注意。
      // ただし、reservationApi.jsのgetRecordはreservationsコレクションを見ているため、
      // DayRecordが保存するoralCareRecordsとは異なる。
      // したがって、ここもoralCareRecordsから取得するように変更すべき。
      // recordsByDateから取得すれば通信も減らせる。

      // recordsByDateがまだロードされていない可能性もあるので、
      // 個別に取得するか、recordsByDateのロードを待つか。
      // シンプルに recordsByDate から引くように変更する。
      // ただし、初回ロード時は recordsByDate が空かもしれない。
    }
  }, [currentUser]); // 未使用だがロジック検討用

  // 初期ロード時 & ユーザー変更時に全記録を取得
  useEffect(() => {
    fetchAllRecords();
  }, [fetchAllRecords]);

  // 日付選択変更時または全記録更新時に、選択中のrecordを更新
  useEffect(() => {
    if (selectedDate && recordsByDate) {
      setRecord(recordsByDate[selectedDate] || null);
    }
  }, [selectedDate, recordsByDate]);

  // 日付クリック時の処理
  const handleDateClick = (dateString) => {
    setSelectedDate(dateString);
    // recordの更新はuseEffectで行われる
  };

  const handleLogout = () => {
    navigate("/logout");
  };

  return (
    <div style={{ padding: 20 }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%" }}>
        <h1 className="text-xl font-bold text-blue-600">Smile Calendar</h1>
        <button
          onClick={handleLogout}
          className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-1 px-3 rounded text-sm"
          style={{ marginLeft: "auto" }}
        >
          ログアウト
        </button>
      </header>

      <div className="mt-4">
        <CalendarUI
          onSelectDate={handleDateClick}
          recordsByDate={recordsByDate}
        />
      </div>

      {selectedDate && (
        <div style={{ marginTop: 20 }}>
          <DayRecord
            dateKey={selectedDate}
            record={record}
            onSave={fetchAllRecords} // 保存後に全記録を再取得してカレンダー更新
          />
        </div>
      )}
    </div>
  );
}
