import React, { useState } from "react";
import { createReservation } from "../api/reservationApi";

function ReservationForm() {
  const [title, setTitle] = useState("");
  const [date, setDate] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async () => {
    try {
      setError("");

      await createReservation({
        title,
        date,
      });

      alert("予約が登録されました");
      setTitle("");
      setDate("");
    } catch (err) {
      console.error("予約エラー:", err);
      setError("予約に失敗しました");
    }
  };

  return (
    <div>
      <h2>予約登録</h2>

      {error && <p style={{ color: "red" }}>{error}</p>}

      <div>
        <label>タイトル：</label>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
      </div>

      <div>
        <label>日付：</label>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
      </div>

      <button onClick={handleSubmit}>保存</button>
    </div>
  );
}

export default ReservationForm;
