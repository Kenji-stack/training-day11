# Smile Calendar Project (Exported)

このディレクトリは、GitHub公開用にエクスポートされた「Smile Calendar」プロジェクトのソースコードです。
機密情報（APIキーなど）は削除されています。

## セットアップ手順

### 1. 依存関係のインストール
ターミナルでこのディレクトリを開き、以下のコマンドを実行してください。

```bash
npm install
```

### 2. Firebase設定
`src/firebase.js` を開き、`firebaseConfig` オブジェクト内のプレースホルダー（`YOUR_API_KEY` など）を、ご自身のFirebaseプロジェクトの設定値に書き換えてください。

```javascript
const firebaseConfig = {
  apiKey: "実際のAPIキー",
  authDomain: "実際のAuthドメイン",
  projectId: "実際のプロジェクトID",
  // ...
};
```

### 3. ローカルサーバーの起動
以下のコマンドで開発サーバーを起動します。

```bash
npm start
```
ブラウザで `http://localhost:3000` が開きます。

## デプロイ方法

Firebase Hostingにデプロイする場合は、以下のコマンドを実行します（事前にFirebase CLIのログインとプロジェクト設定が必要です）。

```bash
npm run deploy
```

## 注意事項
- このコードを公開リポジトリにプッシュする際は、**ご自身のAPIキーを含まないように**十分注意してください。
- `.env` ファイルを使用するなどして、環境変数を管理することを推奨します。
