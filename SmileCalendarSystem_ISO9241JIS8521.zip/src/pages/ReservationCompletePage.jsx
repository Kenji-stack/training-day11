import React from "react";
import { useLocation, useNavigate } from "react-router-dom";

export default function ReservationCompletePage() {
  const location = useLocation();
  const navigate = useNavigate();
  const data = location.state;

  return (
    <div className="max-w-md mx-auto mt-10 p-6 bg-white rounded-lg shadow-md text-center">
      <div className="mb-6 text-green-500">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
        </svg>
      </div>

      <h2 className="text-2xl font-bold mb-4 text-gray-800">予約を保存しました！</h2>

      {data && (
        <div className="bg-gray-50 p-4 rounded-md mb-6 text-left">
          <p className="mb-2"><span className="font-semibold text-gray-600">日付：</span>{data.date}</p>
          <p className="mb-2"><span className="font-semibold text-gray-600">タイトル：</span>{data.title || "(未入力)"}</p>
          <p><span className="font-semibold text-gray-600">メモ：</span>{data.memo || "(未入力)"}</p>
        </div>
      )}

      <button
        onClick={() => navigate("/")}
        className="w-full bg-blue-600 text-white font-bold py-2 px-4 rounded hover:bg-blue-700 transition duration-200"
      >
        カレンダーに戻る
      </button>
    </div>
  );
}
