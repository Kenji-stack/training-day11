// src/pages/CalendarPage.jsx
import React, { useState, useEffect } from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import DayRecord from "../components/DayRecord";
import { getRecord } from "../firebase/reservationApi";

export default function CalendarPage() {
  const navigate = useNavigate();
  const { currentUser } = useAuth();

  const [selectedDate, setSelectedDate] = useState(() => {
    const today = new Date();
    return today.toISOString().split("T")[0];
  });
  const [record, setRecord] = useState(null);

  // ページ読み込み時に今日の記録を取得
  useEffect(() => {
    if (currentUser && selectedDate) {
      getRecord(currentUser.uid, selectedDate).then(data => {
        setRecord(data);
      });
    }
  }, [currentUser, selectedDate]);

  // 日付クリック時の処理
  const handleDateClick = async (dateObj) => {
    const date = dateObj.toISOString().split("T")[0];
    setSelectedDate(date);
    if (currentUser) {
      const data = await getRecord(currentUser.uid, date);
      setRecord(data);
    }
  };

  const handleLogout = () => {
    navigate("/logout");
  };

  return (
    <div style={{ padding: 20 }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%" }}>
        <h1>カレンダー</h1>
        <button onClick={handleLogout} style={{ marginLeft: "auto" }}>ログアウト</button>
      </header>

      <Calendar onClickDay={handleDateClick} locale="ja-JP" />

      {selectedDate && (
        <div style={{ marginTop: 40 }}>
          <DayRecord dateKey={selectedDate} record={record} />
        </div>
      )}
    </div>
  );
}
