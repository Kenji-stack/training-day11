// src/firebase/reservationApi.js
import { doc, getDoc, setDoc, deleteDoc } from "firebase/firestore";
import { auth, db } from "../firebase";

/**
 * 指定日の記録を取得
 */
export async function getRecord(date) {
  const user = auth.currentUser;
  if (!user) return null;

  const ref = doc(db, "reservations", date);
  const snap = await getDoc(ref);

  if (!snap.exists()) return null;
  return snap.data();
}

/**
 * 指定日の記録を更新（上書き保存）
 */
export async function updateRecord(date, data) {
  console.log("updateRecord 開始:", { date, data });

  const user = auth.currentUser;
  console.log("Current user:", user);

  if (!user) {
    console.error("ユーザーがログインしていません");
    throw new Error("User not logged in");
  }

  const ref = doc(db, "reservations", date);
  console.log("Firestore参照:", ref.path);

  try {
    console.log("setDoc 実行中...");

    // タイムアウト付きでsetDocを実行
    await Promise.race([
      setDoc(ref, { ...data, uid: user.uid }, { merge: true }),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error("Timeout")), 5000)
      )
    ]);

    console.log("setDoc 成功！");
    return true;
  } catch (error) {
    if (error.message === "Timeout") {
      console.warn("setDoc がタイムアウトしましたが、データは保存されている可能性があります");
      // タイムアウトでも成功として扱う
      return true;
    }
    console.error("setDoc エラー:", error);
    throw error;
  }
}

/**
 * 指定日の記録を削除
 */
export async function deleteRecord(date) {
  const user = auth.currentUser;
  if (!user) throw new Error("User not logged in");

  const ref = doc(db, "reservations", date);
  await deleteDoc(ref);

  return true;
}
