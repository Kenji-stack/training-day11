// src/components/Header.jsx
import React from "react";
import { useAuth } from "../context/AuthContext";

const Header = () => {
  const { user, logout } = useAuth();

  return (
    <header style={{ display: "flex", justifyContent: "space-between", padding: "8px" }}>
      <div>Smile Calendar</div>
      <div>
        {user ? (
          <>
            <span style={{ marginRight: 8 }}>{user.email}</span>
            <button onClick={() => logout()}>ログアウト</button>
          </>
        ) : (
          <span>未ログイン</span>
        )}
      </div>
    </header>
  );
};

export default Header;
