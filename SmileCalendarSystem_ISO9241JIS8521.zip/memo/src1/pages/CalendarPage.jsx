import React from 'react';
import { useNavigate } from 'react-router-dom';
import ReservationList from '../components/ReservationList';

export default function CalendarPage() {
  const navigate = useNavigate();
  return (
    <div style={{ padding: 20 }}>
      <h1>カレンダー一覧</h1>
      <button onClick={() => navigate('/reservation/new')}>新規予約</button>
      <div style={{ marginTop: 20 }}>
        <ReservationList />
      </div>
    </div>
  );
}