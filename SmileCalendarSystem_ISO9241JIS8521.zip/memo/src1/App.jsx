// src/App.jsx
import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";

import { AuthProvider, useAuth } from "./context/AuthContext";

// --- Pages ---
import Login from "./pages/Login";
import CalendarPage from "./pages/CalendarPage";
import ReservationFormPage from "./pages/ReservationFormPage";
import ReservationConfirmPage from "./pages/ReservationConfirmPage";
import ReservationCompletePage from "./pages/ReservationCompletePage";


// -------- PrivateRoute --------
const PrivateRoute = ({ children }) => {
  const { currentUser } = useAuth();

  if (!currentUser) return <Navigate to="/login" replace />;
  return children;
};


// -------- App Component --------
export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>

          {/* ▼▼▼ 非ログイン時はログインへ ▼▼▼ */}
          <Route path="/login" element={<Login />} />

          {/* ▼▼▼ ログイン後のみ ▼▼▼ */}
          <Route
            path="/"
            element={
              <PrivateRoute>
                <CalendarPage />
              </PrivateRoute>
            }
          />

          <Route
            path="/reserve"
            element={
              <PrivateRoute>
                <ReservationFormPage />
              </PrivateRoute>
            }
          />

          <Route
            path="/reserve/confirm"
            element={
              <PrivateRoute>
                <ReservationConfirmPage />
              </PrivateRoute>
            }
          />

          <Route
            path="/reserve/complete"
            element={
              <PrivateRoute>
                <ReservationCompletePage />
              </PrivateRoute>
            }
          />

          {/* 不正URLはログインへ */}
          <Route path="*" element={<Navigate to="/login" replace />} />

        </Routes>
      </Router>
    </AuthProvider>
  );
}
